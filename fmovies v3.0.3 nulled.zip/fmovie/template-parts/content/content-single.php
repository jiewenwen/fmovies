<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */


?>

<?php get_template_part( 'template-parts/header/entry-breadcrumb' ); ?>
<div id="watch">
	<?php get_template_part( 'template-parts/watch/content-watch' ); ?>
    <div class="container">
        <?php get_template_part( 'template-parts/watch/content-controls' ); ?>
        <?php get_template_part( 'template-parts/watch/content-servers' ); ?>
        <div class="watch-extra">
            <div class="bl-1">
				<section id="post-<?php the_ID(); ?>" <?php post_class( 'info' ); ?>>
					<div class="poster"> 
						<span>
							<img class="lazyload" loading="lazy" src="<?php echo placeholder; ?>" data-src="<?php echo SinglePoster(); ?>" alt="<?php the_title(); ?>">
						</span> 
					</div>
					<div class="info">
						<div class="rating">
							<span class="stars">
							</span>
							<span class="text"> 
								<span><?php Average(); ?></span><?php echo esc_html__( ' of ', 'fmovie' ) ?><span><?php VoteCount(); ?></span> 
							</span>
							<?php //echo do_shortcode( '[bws-rating]' ); ?>
						</div>
						<?php get_template_part( 'template-parts/header/entry-header' ); ?>
						<div class="meta lg"> 
							<?php Qualita(); ?> 
							<span class="imdb"><i class="fa fa-star"></i> <?php Average(); ?></span> 
							<?php Durata(); ?>
							<span class="stato"></span> 
							<?php echo edit_post_link( __( 'edit', 'fmovie' ), '<span>', '</span>' ); ?>
						</div>
						<div class="desc shorting"><?php the_content(); ?></div>
						<div class="meta">
							<?php SingleCountry(); ?>
							<?php SingleGenres(); ?>
							<?php SingleYear(); ?>
							<?php Regista(); ?>
							<?php SingleActors(); ?>
							<?php Keywords(); ?>
						</div>
					</div>
					<div class="clearfix"></div>
				</section><!-- #post-<?php the_ID(); ?> -->
                <?php comments_template(); ?>
			</div>
			<?php get_template_part( 'template-parts/content/content', 'sponsor' ); ?>
            <?php get_template_part( 'template-parts/content/content', 'related' ); ?>
            <div class="clearfix"></div>
		</div>
	</div>
</div>
<div id="overlay"></div>
<?php echo Trailer(); ?>
<?php echo report_content(); ?>
