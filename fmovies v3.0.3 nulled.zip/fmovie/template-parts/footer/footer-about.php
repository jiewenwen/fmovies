<?php
/**
 * Template part for additional info on footer
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package fmovie
 */
$color_style = get_option('admin_color_style');
$blog_info    = get_bloginfo( 'name' );
$footer_logo_class = 'logo_txt';
?>

<div class="about">

		<?php if( function_exists( 'the_custom_logo' ) ) { if( has_custom_logo() ) { ?>
			<div class="logo"><?php the_custom_logo(); ?></div>
			<?php } else { ?>

			<div class="<?php echo esc_attr( $footer_logo_class ); ?>"><?php echo esc_html( $blog_info ); ?></div>
		<?php } ?>
		<?php } ?>
		<div class="desc">
			<p><?php echo slogan; ?></p>
			<p class="footer-copyright"><?php echo esc_html( $blog_info ); ?> &copy;
			<?php
			echo date_i18n(
			/* translators: Copyright date format, see https://www.php.net/manual/datetime.format.php */
			_x( 'Y', 'copyright date format', 'fmovie' )
			);
			?><?php echo esc_html__( '. All Rights Reserved', 'fmovie' ) ?>
			</p><!-- .footer-copyright -->
			<?php echo credits(); ?>
			<p class="small font-italic"><?php echo esc_html__( 'This site does not store any files on our server, we only linked to the media which is hosted on 3rd party services.', 'fmovie' ) ?></p>
		</div>

</div>