<?php
/**
 * Displays the post header
 *
 * @package fmovie
 */

the_title( '<h1 itemprop="name" class="title entry-title">', '</h1>' );
